/* Firebase Cloud Messaging service worker — handles push notifications
   while the app tab is closed or in the background.
   Keep the config in sync with src/firebase.js */

/* Self-hosted copies of the Firebase compat bundles (from node_modules/firebase/)
   so the service worker doesn't depend on the gstatic CDN */
importScripts('/firebase-app-compat.js');
importScripts('/firebase-messaging-compat.js');

firebase.initializeApp({
  apiKey: 'AIzaSyDhTmysW8dCJQl80iEC2VEseWAShJuruKA',
  authDomain: 'bidndrive-65be3.firebaseapp.com',
  projectId: 'bidndrive-65be3',
  storageBucket: 'bidndrive-65be3.firebasestorage.app',
  messagingSenderId: '627802907244',
  appId: '1:627802907244:web:af15122f58ba86ce936e49',
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  const title = payload.notification?.title || payload.data?.title || 'BidNDrive';
  const options = {
    body: payload.notification?.body || payload.data?.body || '',
    icon: payload.notification?.icon || '/favicon.png',
    data: { url: payload.fcmOptions?.link || payload.data?.url || '/' },
  };
  self.registration.showNotification(title, options);
});

// Focus an existing tab (or open one) when the notification is clicked
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const url = event.notification.data?.url || '/';
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((windowClients) => {
      for (const client of windowClients) {
        if ('focus' in client) {
          client.focus();
          if (url !== '/') client.navigate(url);
          return;
        }
      }
      return clients.openWindow(url);
    })
  );
});
